import { useState } from 'react'
import { Routes, Route } from 'react-router-dom';
import ToDo from './ToDo';

function App() {

  return (
    <>
      <div>
        <ToDo />
      </div>
    </>
  )
}

export default App