import { useState } from 'react';

function App(props) {
    const [dueDateError, setDueDateError] = useState(false);
    const [inputError, setInputError] = useState(false);
    const [textError, settextError] = useState("");
    const [Task, setTask] = useState({
        Title: "",
        Description: "",
        Due: "",
        checked: false
    });

    const handleDueChange = (e) => {
        const selectedDate = new Date(e.target.value);
        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        if (selectedDate < currentDate) {
            setDueDateError(true);
        } else {
            setDueDateError(false);
            setTask((prevTask) => ({
                ...prevTask,
                Due: e.target.value
            }));
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setTask((prevTask) => ({
            ...prevTask,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!Task.Title) {
            setInputError(true);
            settextError('โปรดใส่หัวข้อ');
            return;
        } else if (!Task.Description) {
            setInputError(true);
            settextError('โปรใส่รายละเอียด');
            return;
        } else if (!Task.Due) {
            setInputError(true);
            settextError('โปรใส่วันที่');
            return;
        } else {
            setInputError(false);
        }

        try {
            const response = await fetch('http://localhost:5000/tasks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    title: Task.Title,
                    description: Task.Description,
                    due: Task.Due,
                }),
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }
            setTask({
                Title: "",
                Description: "",
                Due: "",
                checked: false
            });

            props.setDisplayComponent("ToDo_show");

        } catch (error) {
            console.error("Error adding task:", error);
        }
    };




    return (
        <>
            <div className="flex pt-20 pb-40 justify-center min-h-screen bg-gray-100">
                <div className="custom-size mx-auto px-4 pt-5 pb-6 bg-white shadow-lg rounded-lg border border-gray-300">

                    <div className="flex justify-between items-center mb-6">
                        <h1 className="text-4xl font-bold text-gray-800">Add Task</h1>
                        <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200" onClick={() => props.setDisplayComponent("ToDo_show")}>Backward</button>
                    </div>

                    <div className="flex-col mx-auto p-4">
                        <form className="flex flex-col">

                            <div className="mb-4">
                                <label className="form-control">
                                    <div className="label mb-2"><span className="label-text text-gray-700">Title<span className="text-red-500"> *</span></span></div>
                                    <input type="text" name="Title" value={Task.Title} onChange={handleInputChange} placeholder="Placeholder" className="input input-bordered w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" required />
                                </label>
                            </div>

                            <div className="mb-4">
                                <label className="form-control">
                                    <div className="label mb-2"><span className="label-text text-gray-700">Description<span className="text-red-500"> *</span></span></div>
                                    <textarea name="Description" value={Task.Description} onChange={handleInputChange} placeholder="Type here" className="input input-bordered w-full h-32 p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500" required />
                                </label>
                            </div>

                            <div className="mb-4">
                                <label className="form-control">
                                    <div className="label mb-2">
                                        <span className="label-text text-gray-700">Due <span className="text-red-500"> *</span></span>
                                    </div>
                                    <input
                                        type="date"
                                        name="Due"
                                        value={Task.Due}
                                        onChange={handleDueChange}
                                        className="input input-bordered w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                                        required
                                        onKeyDown={(e) => e.preventDefault()}
                                        onPaste={(e) => e.preventDefault()}
                                    />
                                </label>
                                {dueDateError && <p className="text-red-500 mt-2">โปรดใส่วันที่ไม่น้อยกว่าปัจจุบัน</p>}
                            </div>

                            <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200" onClick={handleSubmit}>Add Task</button>
                            {inputError && <p className="text-red-500 mt-2">{textError}</p>}
                        </form>
                    </div>
                </div>
            </div>

        </>
    );
}

export default App;
