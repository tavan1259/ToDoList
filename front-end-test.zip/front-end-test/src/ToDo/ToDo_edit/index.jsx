import { useState, useEffect } from 'react';

function App(props) {
    const [dueDateError, setDueDateError] = useState(false);
    const [inputError, setInputError] = useState(false);

    useEffect(() => {
        setInputError(false);
        setDueDateError(false);
    }, [props.Task]);



    const handleInputChange = (e) => {
        const { name, value } = e.target;
        props.setTask((prevTask) => ({
            ...prevTask,
            [name]: value
        }));
    };

    const handleDueChange = (e) => {
        const selectedDate = new Date(e.target.value);
        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        if (selectedDate < currentDate) {
            setDueDateError(true);
        } else {
            setDueDateError(false);
            props.setTask((prevTask) => ({
                ...prevTask,
                due: e.target.value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!props.Task.title || !props.Task.description || !props.Task.due) {
            setInputError(true);
            return;
        } else {
            setInputError(false);
        }
        const date = formatDateToYYYYMMDD(new Date(props.Task.due));
        try {
            const response = await fetch(`http://localhost:5000/tasks/${props.Task.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    title: props.Task.title,
                    description: props.Task.description,
                    due: date,
                    checked: props.Task.checked
                }),
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const updatedTask = await response.json();

            props.setDisplayComponent("ToDo_show");
        } catch (error) {
            console.error('Error updating task:', error);
        }
    };

    const formatDateToYYYYMMDD = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    };


    return (
        <>
            <div className="flex pt-20 pb-40 justify-center min-h-screen bg-gray-100">
                <div className="custom-size mx-auto px-4 pt-5 pb-6 bg-white shadow-lg rounded-lg border border-gray-300">
                    <div className="flex justify-between items-center mb-6">
                        <h1 className="text-4xl font-bold text-gray-800">Edit Task</h1>
                        <button
                            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200"
                            onClick={() => props.setDisplayComponent("ToDo_show")}>
                            Backward
                        </button>
                    </div>

                    <div className="flex-col mx-auto p-4">
                        <form className="flex flex-col" onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <label className="form-control">
                                    <div className="label mb-2">
                                        <span className="label-text text-gray-700">Title<span className="text-red-500"> *</span></span>
                                    </div>
                                    <input
                                        type="text"
                                        name="title"
                                        value={props.Task.title}
                                        onChange={handleInputChange}
                                        placeholder="Placeholder"
                                        className="input input-bordered w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                                        required
                                    />
                                </label>
                            </div>

                            <div className="mb-4">
                                <label className="form-control">
                                    <div className="label mb-2">
                                        <span className="label-text text-gray-700">Description<span className="text-red-500"> *</span></span>
                                    </div>
                                    <textarea
                                        name="description"
                                        value={props.Task.description}
                                        onChange={handleInputChange}
                                        placeholder="Type here"
                                        className="input input-bordered w-full h-32 p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                                        required
                                    />
                                </label>
                            </div>
                            <div className="mb-4">
                                <label className="form-control">
                                    <div className="label mb-2">
                                        <span className="label-text text-gray-700">Due<span className="text-red-500"> *</span></span>
                                    </div>
                                    <input
                                        type="date"
                                        name="due"
                                        value={props.Task.due ? formatDateToYYYYMMDD(new Date(props.Task.due)) : ''}
                                        onChange={handleDueChange}
                                        className="input input-bordered w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                                        required
                                    />

                                </label>
                                {dueDateError && <p className="text-red-500 mt-2">โปรดใส่วันที่ไม่น้อยกว่าปัจจุบัน</p>}
                            </div>


                            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200">Edit Task</button>
                            {inputError && <p className="text-red-500 mt-2">Please fill out all fields!</p>}
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}

export default App;
