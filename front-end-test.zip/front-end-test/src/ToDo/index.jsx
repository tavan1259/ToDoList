import { useState } from 'react'

import ToDo_show from './ToDo_show';
import ToDo_add from './ToDo_add';
import ToDo_edit from './ToDo_edit';

function App() {
    const [displayComponent, setDisplayComponent] = useState("ToDo_show");
    const [Task, setTask] = useState(null);

    return (
        <>
            {displayComponent === "ToDo_show" && <ToDo_show Task={Task} setTask={setTask} setDisplayComponent={setDisplayComponent} />}
            {displayComponent === "ToDo_add" && <ToDo_add setDisplayComponent={setDisplayComponent} />}
            {displayComponent === "ToDo_edit" && <ToDo_edit Task={Task} setTask={setTask} setDisplayComponent={setDisplayComponent} />}
        </>
    )
}

export default App