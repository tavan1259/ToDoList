import { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faPen } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';

function App(props) {
    const [tasks, setTasks] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [taskToDelete, setTaskToDelete] = useState(null);

    useEffect(() => {
        axios.get('http://localhost:5000/tasks')
            .then(response => setTasks(response.data))
            .catch(error => console.error("Error fetching tasks:", error));
    }, []);

    const handleCheckboxChange = (index) => {
        const updatedTask = { ...tasks[index], checked: !tasks[index].checked };
        axios.put(`http://localhost:5000/tasks/${tasks[index].id}`, updatedTask)
            .then(() => {
                setTasks((prevTasks) =>
                    prevTasks.map((t, i) => (i === index ? updatedTask : t))
                );
            })
            .catch(error => console.error("Error updating task:", error));
    };

    const handleEdit = (index) => {
        props.setTask(tasks[index]);
        props.setDisplayComponent("ToDo_edit");
    };

    const handleDelete = () => {
        axios.delete(`http://localhost:5000/tasks/${tasks[taskToDelete].id}`)
            .then(() => {
                setTasks((prevTasks) => prevTasks.filter((_, i) => i !== taskToDelete));
                setShowModal(false);
            })
            .catch(error => console.error("Error deleting task:", error));
    };

    const openDeleteModal = (index) => {
        setTaskToDelete(index);
        setShowModal(true);
    };

    const formatDateToYYYYMMDD = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        return `${day}-${month}-${year}`;
    };

    return (
        <>
            <div className="flex pt-20 pb-40 justify-center min-h-screen bg-gray-100">
                <div className="custom-size mx-auto px-6 pt-8 pb-6 border border-black bg-white rounded-lg shadow-lg">
                    <h1 className="text-4xl font-bold text-left text-gray-800 mb-6">To-Do List</h1>

                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800">My Tasks</h2>
                            <h3 className="text-xl text-gray-600">You have {tasks.length} task left!</h3>
                        </div>
                        <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-200" onClick={() => props.setDisplayComponent("ToDo_add")}>Add Task</button>
                    </div>

                    <div className="mt-4" style={{ maxHeight: '450px', overflowY: 'auto' }}>
                        <h2 className="text-lg font-semibold text-gray-800">Task List:</h2>
                        <ul className="divide-y divide-gray-300">
                            {tasks.map((task, index) => (
                                <li key={index} className="mb-4 p-4 border border-gray-300 rounded-lg shadow-md bg-gray-50 hover:bg-gray-100 transition duration-200">
                                    <div className="flex justify-between items-center">
                                        <div className="flex items-center">
                                            <input
                                                type="checkbox"
                                                checked={task.checked}
                                                onChange={() => handleCheckboxChange(index)}
                                                className="mr-2"
                                            />
                                            <strong style={{ textDecoration: task.checked ? "line-through" : "none", color: task.checked ? "gray" : "black" }}>
                                                {task.title}
                                            </strong>
                                        </div>
                                        <div>
                                            <button className="ml-2" onClick={() => handleEdit(index)}>
                                                <FontAwesomeIcon icon={faPen} style={{ color: 'green' }} />
                                            </button>
                                            <button className="ml-2 text-red-500" onClick={() => openDeleteModal(index)}>
                                                <FontAwesomeIcon icon={faTrash} />
                                            </button>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-md text-gray-600 truncate-lines pl-4 pr-8">
                                            {task.description}
                                        </p>
                                        <p className="text-md text-red-600 truncate-lines pl-4">
                                            Due: {isNaN(new Date(task.due)) ? 'Invalid date' : formatDateToYYYYMMDD(new Date(task.due))}
                                        </p>

                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>

            {showModal && (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75">
                    <div className="bg-white p-4 rounded shadow-lg">
                        <h2 className="text-xl text-center font-bold">Are you sure?</h2>
                        <p>Do you want to delete item.</p>
                        <div className="mt-4 flex justify-center">
                            <button className="bg-gray-300 px-8 py-2 rounded mr-2" onClick={() => setShowModal(false)}>No</button>
                            <button className="bg-red-500 text-white px-8 py-2 rounded" onClick={handleDelete}>Yes</button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}

export default App;
