const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bodyParser = require('body-parser');

const app = express();


const port = 5000;

const pool = new Pool({
    user: 'wygsbqut',
    host: 'arjuna.db.elephantsql.com',
    database: 'wygsbqut',
    password: 'I6NV_hTIxtoFEQs0T4NLzd31Iykft6-x',
    port: 5432
  });
  

app.use(cors());
app.use(bodyParser.json());

app.get('/tasks', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM tasks ORDER BY id');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/tasks', async (req, res) => {
    const { title, description, due } = req.body;  
  
    if (!title || !description || !due) {
      return res.status(400).json({ error: "Title, description, and due date are required." });
    }
  
    try {
      const result = await pool.query(
        'INSERT INTO tasks (title, description, due, checked) VALUES ($1, $2, $3, $4) RETURNING *',
        [title, description, due, false]
      );
      res.json(result.rows[0]);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
  

app.post('/tasks', async (req, res) => {
    console.log('Received a POST request:', req.body);
  });

app.put('/tasks/:id', async (req, res) => {
  const { id } = req.params;
  const { title, description, due, checked } = req.body;
  try {
    const result = await pool.query(
      'UPDATE tasks SET title = $1, description = $2, due = $3, checked = $4 WHERE id = $5 RETURNING *',
      [title, description, due, checked, id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/tasks/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
    res.json({ message: 'Task deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
